Project: MinidroneCompetition

This example is the reference model to be used by participants of the MathWorks Minidrone Competition. It demonstrates how Simulink(R) is used to model the PARROT Mambo Minidrone. The algorithm can be directly deployed on the Parrot Mambo hardware using the Simulink Support Package for Parrot Minidrones.